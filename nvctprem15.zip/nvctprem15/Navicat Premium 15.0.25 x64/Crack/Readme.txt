Copy Keygen & Patch to installation folder & run it
=================